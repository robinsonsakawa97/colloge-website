
  <?php include "navigation.inc"?>
  <?php include "header.inc"?>
  <div class="home_bg">
    <h1>About Our College</h1>
    <p><b><h3> Lorem ipsum dolor sit amet consectetur adipisicing elit. Velit quae ullam autem. Accusantium, cum et, consectetur eum in harum, porro labore accusamus ipsum beatae excepturi numquam. Nesciunt quas molestias cupiditate.</h3></b></p>
  </div>
  <?php include "footer.inc"?>